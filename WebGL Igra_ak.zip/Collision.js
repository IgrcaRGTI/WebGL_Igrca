
function CanIMove(meshes,position,position, direction, dist)
{




    for (var i = 0; i < meshes.length; i++) {
        var mesh = meshes[i];
        var vertices = mesh.vertices;
        console.log(vertices.length);


    }
    return true;

        }